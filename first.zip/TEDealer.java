import java.util.ArrayList;

public class TEDealer extends Dealer{

}