import java.util.ArrayList;

public abstract class Dealer{
    protected int Did;                   // Dealer's id
    protected String Dname;              // Dealer's name
    protected int Dbalance;              // Dealer's money
    protected Hand Dhand;                // Dealer's hand card in each round
    protected Deck deck;                 // Dealer holds the deck of cards

    public Dealer(){}

    public Dealer(int id, String name, int balance){
        this.Did = id;
        this.Dname = name;
        this.Dbalance = balance;
        this.Dhand = new Hand();
        this.Deck = new Deck();
    }

    public int getId(){
        return Did;
    }

    public void setId(int id){
        this.Did = id;
    }

    public String getName(){
        return Dname;
    }

    public void setName(String name){
        this.Dname = name;
    }

    public int getBalance(){
        return Dbalance;
    }

    public void setBalance(int balance){
        this.Dbalance = balance;
    }

    public Hand getHand(){
        return Dhand;
    }

    public Deck getDeck(){
        return deck;
    }

    public abstract Card deal();            // Dealer can deal cards to all gamblers

    public abstract void hit();             // Dealer can automatically hit

    public abstract Card turnFace();        // Dealer can turn the face-down card up




}

