import java.util.ArrayList;

public class BJPlayer extends Player{

}
