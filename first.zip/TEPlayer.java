import java.util.ArrayList;

public class TEPlayer extends Player{

}
