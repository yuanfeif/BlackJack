import java.util.ArrayList;

public class BJDealer extends Dealer{

}